namespace ClaudeVSGui
{
	using System;
	using System.ComponentModel.Design;
	using System.Diagnostics;
	using System.IO;
	using System.Linq;
	using System.Windows;
	using System.Windows.Media.Imaging;
	using Microsoft.VisualStudio.Shell;
	using Microsoft.VisualStudio.Shell.Interop;
	using Microsoft.Win32;
	using Task = System.Threading.Tasks.Task;

	internal sealed class SendImageCommand
	{
		public const int CommandId = 0x0112;
		public const int ClipboardCommandId = 0x0113;

		public static readonly Guid CommandSet = new Guid("a7c8e9d0-1234-5678-9abc-def012345678");

		private readonly AsyncPackage package;

		private static readonly string[] ImageExtensions =
			{ ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg" };

		private SendImageCommand(AsyncPackage package, OleMenuCommandService commandService)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			if (package == null)
			{
				Debug.WriteLine("ArgumentNullException in SendImageCommand constructor: package is null");
				throw new ArgumentNullException(nameof(package));
			}
			if (commandService == null)
			{
				Debug.WriteLine("ArgumentNullException in SendImageCommand constructor: commandService is null");
				throw new ArgumentNullException(nameof(commandService));
			}
			this.package = package;

			var menuCommandID = new CommandID(CommandSet, CommandId);
			var menuItem = new MenuCommand(this.Execute, menuCommandID);
			commandService.AddCommand(menuItem);

			var clipboardCommandID = new CommandID(CommandSet, ClipboardCommandId);
			var clipboardItem = new MenuCommand(this.ExecuteFromClipboard, clipboardCommandID);
			commandService.AddCommand(clipboardItem);
		}

		public static SendImageCommand Instance
		{
			get;
			private set;
		}

		private IAsyncServiceProvider ServiceProvider
		{
			get { return this.package; }
		}

		public static async Task InitializeAsync(AsyncPackage package)
		{
			await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync(package.DisposalToken);

			OleMenuCommandService commandService = await package.GetServiceAsync(typeof(IMenuCommandService)) as OleMenuCommandService;
			Instance = new SendImageCommand(package, commandService);
		}

		public void ExecuteFromButton()
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			Execute(null, EventArgs.Empty);
		}

		private void Execute(object sender, EventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();

			try
			{
				var openFileDialog = new OpenFileDialog
				{
					Title = "Select Image File(s)",
					Filter = "Image Files|*.png;*.jpg;*.jpeg;*.gif;*.bmp;*.webp;*.svg|All Files|*.*",
					Multiselect = true
				};

				if (openFileDialog.ShowDialog() == true)
				{
					var validPaths = openFileDialog.FileNames
						.Where(p => File.Exists(p) && IsImageFile(p))
						.ToArray();

					if (validPaths.Length == 0)
					{
						Debug.WriteLine("SendImageCommand: No valid image files selected");
						return;
					}

					SendImagesToTerminal(validPaths);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SendImageCommand Execute: {ex}");
			}
		}

		private void ExecuteFromClipboard(object sender, EventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();

			try
			{
				if (!Clipboard.ContainsImage())
				{
					Debug.WriteLine("SendImageCommand: No image in clipboard");
					return;
				}

				string tempFilePath = SaveClipboardImageToTemp();
				if (!string.IsNullOrEmpty(tempFilePath))
				{
					SendImagesToTerminal(new[] { tempFilePath });
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SendImageCommand ExecuteFromClipboard: {ex}");
			}
		}

		private bool IsImageFile(string filePath)
		{
			string ext = Path.GetExtension(filePath).ToLowerInvariant();
			return ImageExtensions.Contains(ext);
		}

		private string SaveClipboardImageToTemp()
		{
			try
			{
				var image = Clipboard.GetImage();
				if (image == null)
				{
					Debug.WriteLine("SendImageCommand: Failed to get image from clipboard");
					return null;
				}

				string tempDir = Path.Combine(Path.GetTempPath(), "ClaudeVSGui");
				Directory.CreateDirectory(tempDir);

				string tempFile = Path.Combine(tempDir, $"clipboard_{DateTime.Now:yyyyMMdd_HHmmss}.png");
				string normalizedTempDir = Path.GetFullPath(tempDir).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
				if (!Path.GetFullPath(tempFile).StartsWith(normalizedTempDir, StringComparison.OrdinalIgnoreCase))
				{
					return null;
				}

				using (var fileStream = new FileStream(tempFile, FileMode.Create))
				{
					BitmapEncoder encoder = new PngBitmapEncoder();
					encoder.Frames.Add(BitmapFrame.Create(image));
					encoder.Save(fileStream);
				}

				Debug.WriteLine($"SendImageCommand: Saved clipboard image to {tempFile}");
				return tempFile;
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"SendImageCommand: Failed to save clipboard image: {ex}");
				return null;
			}
		}

		private void SendImagesToTerminal(string[] imagePaths)
		{
			ThreadHelper.ThrowIfNotOnUIThread();

			try
			{
				ToolWindowPane terminalWindow = this.package.FindToolWindow(typeof(ClaudeTerminal), 0, true);
				if (terminalWindow?.Frame is IVsWindowFrame terminalFrame)
				{
					Microsoft.VisualStudio.ErrorHandler.ThrowOnFailure(terminalFrame.Show());

					if (terminalWindow.Content is ClaudeTerminalControl control)
					{
						string imageMessage = string.Join(" ", imagePaths.Select(p => "@" + p));
						control.SendUserPaste(imageMessage, true);
						control.FocusTerminal();
						Debug.WriteLine($"SendImageCommand: Sent {imagePaths.Length} image path(s) to terminal");
					}
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SendImagesToTerminal: {ex}");
			}
		}
	}
}
