namespace ClaudeVSGui
{
	using System;
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.Reflection;
	using System.Text;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Controls.Primitives;
	using System.Windows.Input;
	using System.Windows.Interop;
	using System.Windows.Media;
	using System.Windows.Threading;
	using Microsoft.Terminal.Wpf;
	using Microsoft.VisualStudio.Shell;

	public partial class ClaudeTerminalControl
	{
		private class AgentTab
		{
			public string Title;
			public TabItem TabItem;
			public TerminalControl TerminalControl;
			public Border TerminalBorder;
			public ConPtyTerminal Terminal;
			public ConPtyTerminalConnection Connection;
			public IntPtr TerminalHandle = IntPtr.Zero;
			public IntPtr TerminalHwnd = IntPtr.Zero;
			public DispatcherTimer SelectionScrollTimer;
			public object TermContainerInstance;
			public ScrollBar TerminalScrollbar;
			public MethodInfo UserScrollMethod;
			public bool IsInitialized;
			public bool NeedsResizeAfterOutput;
			public string CurrentSolutionPath;
			public DispatcherTimer RefreshTimer;
			public DateTime LastOutputTime = DateTime.MinValue;
			public string Command;
			public EventHandler<string> OutputReceivedHandler;
			public bool MouseHookInstalled;
			public readonly object TranscriptLock = new object();
			public readonly StringBuilder RecentTranscript = new StringBuilder();
		}

		private AgentTab CreateNewAgentTab(bool initialize)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			var tab = new AgentTab();
			tab.Title = $"Agent {nextTabIndex++}";
			tab.Command = currentCommand;

			var terminalControl = new TerminalControl
			{
				Background = new SolidColorBrush(GetThemeBackgroundColor()),
				Foreground = new SolidColorBrush(Color.FromRgb(0xD4, 0xD4, 0xD4)),
				IsHitTestVisible = true,
				Focusable = true
			};

			var border = new Border
			{
				HorizontalAlignment = HorizontalAlignment.Left,
				Child = terminalControl
			};

			tab.TerminalControl = terminalControl;
			tab.TerminalBorder = border;

			string effectiveTheme = currentTheme;
			if (effectiveTheme == "System")
			{
				effectiveTheme = IsSystemDarkMode() ? "Dark" : "Light";
			}
			var tabItemStyle = (Style)FindResource(effectiveTheme == "Light" ? "LightTabItemStyle" : "DarkTabItemStyle");
			var closeButtonStyle = (Style)FindResource(effectiveTheme == "Light" ? "LightTabCloseButtonStyle" : "DarkTabCloseButtonStyle");

			var headerPanel = new StackPanel { Orientation = Orientation.Horizontal };
			var headerText = new TextBlock
			{
				Text = tab.Title,
				VerticalAlignment = VerticalAlignment.Center,
				Margin = new Thickness(0, 0, 6, 0)
			};
			var closeButton = new Button
			{
				Style = closeButtonStyle,
				VerticalAlignment = VerticalAlignment.Center,
				Focusable = false,
				IsTabStop = false
			};
			closeButton.Click += CloseTabButton_Click;
			headerPanel.Children.Add(headerText);
			headerPanel.Children.Add(closeButton);

			tab.TabItem = new TabItem
			{
				Header = headerPanel,
				Content = border,
				Style = tabItemStyle
			};

			agentTabs.Add(tab);
			AgentTabs.Items.Add(tab.TabItem);

			UpdateTabVisibility();

			UpdateTerminalMaxWidth(tab);
			ApplyTheme(tab);
			ApplyFontSize(tab);

			if (initialize)
			{
				EnsureTabInitialized(tab);
			}

			return tab;
		}

		private void EnsureTabInitialized(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			if (tab == null || tab.IsInitialized)
			{
				return;
			}

			InitializeConPtyTerminal(tab);
		}

		private void SetActiveTab(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			if (tab == null)
			{
				return;
			}

			activeTab = tab;
			lastUserSelectedTab = tab;
			AgentTabs.SelectedItem = tab.TabItem;
			EnsureTabInitialized(tab);
			UpdateQuickSwitchVisibility();
			FocusTerminal();
		}

		private AgentTab GetTabByItem(object item)
		{
			foreach (var tab in agentTabs)
			{
				if (tab.TabItem == item)
				{
					return tab;
				}
			}
			return null;
		}

		private void AgentTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				UpdateTabVisibility();
				var selectedTab = GetTabByItem(AgentTabs.SelectedItem);
				if (selectedTab != null)
				{
					activeTab = selectedTab;

					if (Mouse.LeftButton == MouseButtonState.Pressed && AgentTabs.IsMouseOver)
					{
						lastUserSelectedTab = selectedTab;
					}

					EnsureTabInitialized(selectedTab);
					FocusTerminal();
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in AgentTabs_SelectionChanged: {ex}");
			}
		}

		private void AgentTabs_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
		{
			var tabToRestore = lastUserSelectedTab;
			if (tabToRestore == null)
			{
				return;
			}

			if (AgentTabs.SelectedItem != tabToRestore.TabItem)
			{
				AgentTabs.SelectedItem = tabToRestore.TabItem;
				activeTab = tabToRestore;
			}

			if (activeTab?.TerminalControl != null)
			{
				var hwndHost = FindVisualChild<HwndHost>(activeTab.TerminalControl);
				if (hwndHost != null && hwndHost.Handle != IntPtr.Zero)
				{
					SetFocus(hwndHost.Handle);
				}
			}
		}

		private void NewAgentButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var tab = CreateNewAgentTab(true);
				SetActiveTab(tab);
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in NewAgentButton_Click: {ex}");
			}
		}

		private void CloseTabButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				if (agentTabs.Count <= 1)
				{
					return;
				}

				var button = sender as Button;
				if (button == null)
				{
					return;
				}

				var headerPanel = button.Parent as StackPanel;
				if (headerPanel == null)
				{
					return;
				}

				AgentTab tabToClose = null;
				foreach (var tab in agentTabs)
				{
					if (tab.TabItem.Header == headerPanel)
					{
						tabToClose = tab;
						break;
					}
				}

				if (tabToClose == null)
				{
					return;
				}

				int tabIndex = agentTabs.IndexOf(tabToClose);
				bool wasActive = (tabToClose == activeTab);

				StopClaude(tabToClose);
				agentTabs.Remove(tabToClose);
				AgentTabs.Items.Remove(tabToClose.TabItem);

				UpdateTabVisibility();

				if (wasActive && agentTabs.Count > 0)
				{
					int newIndex = Math.Min(tabIndex, agentTabs.Count - 1);
					SetActiveTab(agentTabs[newIndex]);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in CloseTabButton_Click: {ex}");
			}
		}

		private void UpdateTabVisibility()
		{
			AgentTabs.Tag = agentTabs.Count >= 2 ? Visibility.Visible : Visibility.Collapsed;
		}
	}
}
