using System.Collections.Generic;
using System.Globalization;
using Microsoft.VisualStudio.Shell;

namespace ClaudeVSGui
{
    public enum Language
    {
        English,
        Chinese
    }

    public static class LanguageManager
    {
        private static Language currentLanguage = GetSystemLanguage();

        public static Language CurrentLanguage
        {
            get => currentLanguage;
            set => currentLanguage = value;
        }

        private static readonly Dictionary<string, Dictionary<Language, string>> translations = new Dictionary<string, Dictionary<Language, string>>
        {
            { "Mic", new Dictionary<Language, string> { { Language.English, "🎤 Mic" }, { Language.Chinese, "🎤 麦克风" } } },
            { "ChangeAgent", new Dictionary<Language, string> { { Language.English, "⚙ Change Agent" }, { Language.Chinese, "⚙ 更换代理" } } },
            { "RestartAgent", new Dictionary<Language, string> { { Language.English, "🔄 Restart Agent" }, { Language.Chinese, "🔄 重启代理" } } },
            { "NewAgent", new Dictionary<Language, string> { { Language.English, "➕ New Agent" }, { Language.Chinese, "➕ 新建代理" } } },
            { "Theme", new Dictionary<Language, string> { { Language.English, "🎨 Theme" }, { Language.Chinese, "🎨 主题" } } },
            { "FontSize", new Dictionary<Language, string> { { Language.English, "🔤 Font Size" }, { Language.Chinese, "🔤 字体大小" } } },
            { "QuickSwitch", new Dictionary<Language, string> { { Language.English, "⚡ QuickSwitch" }, { Language.Chinese, "⚡ 快速切换" } } },
            { "SendImage", new Dictionary<Language, string> { { Language.English, "🖼 Image" }, { Language.Chinese, "🖼 图片" } } },
            { "Language", new Dictionary<Language, string> { { Language.English, "🌐 Language" }, { Language.Chinese, "🌐 语言" } } },

            { "EnterCommand", new Dictionary<Language, string> { { Language.English, "Enter Command" }, { Language.Chinese, "输入命令" } } },
            { "SelectPreset", new Dictionary<Language, string> { { Language.English, "Select a preset:" }, { Language.Chinese, "选择预设：" } } },
            { "OrEnterCommand", new Dictionary<Language, string> { { Language.English, "Or enter command name:" }, { Language.Chinese, "或输入命令名称：" } } },
            { "OK", new Dictionary<Language, string> { { Language.English, "OK" }, { Language.Chinese, "确定" } } },
            { "Cancel", new Dictionary<Language, string> { { Language.English, "Cancel" }, { Language.Chinese, "取消" } } },

            { "FontSizeTitle", new Dictionary<Language, string> { { Language.English, "Font Size" }, { Language.Chinese, "字体大小" } } },
            { "SelectFontSize", new Dictionary<Language, string> { { Language.English, "Select font size:" }, { Language.Chinese, "选择字体大小：" } } },

            { "SelectTheme", new Dictionary<Language, string> { { Language.English, "Select Theme" }, { Language.Chinese, "选择主题" } } },
            { "SelectThemeLabel", new Dictionary<Language, string> { { Language.English, "Select theme:" }, { Language.Chinese, "选择主题：" } } },
            { "System", new Dictionary<Language, string> { { Language.English, "System" }, { Language.Chinese, "系统" } } },
            { "Light", new Dictionary<Language, string> { { Language.English, "Light" }, { Language.Chinese, "浅色" } } },
            { "Dark", new Dictionary<Language, string> { { Language.English, "Dark" }, { Language.Chinese, "深色" } } },

            { "English", new Dictionary<Language, string> { { Language.English, "English" }, { Language.Chinese, "英文" } } },
            { "Chinese", new Dictionary<Language, string> { { Language.English, "中文" }, { Language.Chinese, "中文" } } }
        };

        public static string Get(string key)
        {
            if (translations.TryGetValue(key, out var languageDict))
            {
                if (languageDict.TryGetValue(currentLanguage, out var translation))
                {
                    return translation;
                }
            }
            return key;
        }

        private static Language GetSystemLanguage()
        {
            var culture = CultureInfo.CurrentUICulture;
            if (culture.Name.StartsWith("zh", System.StringComparison.OrdinalIgnoreCase))
            {
                return Language.Chinese;
            }
            return Language.English;
        }

        public static void LoadLanguage()
        {
            ThreadHelper.ThrowIfNotOnUIThread();
            var savedLang = SettingsManager.GetLanguage();
            if (string.IsNullOrEmpty(savedLang) || savedLang == "Auto")
            {
                currentLanguage = GetSystemLanguage();
            }
            else
            {
                currentLanguage = savedLang == "Chinese" ? Language.Chinese : Language.English;
            }
        }

        public static void SaveLanguage()
        {
            ThreadHelper.ThrowIfNotOnUIThread();
            SettingsManager.SaveLanguage(currentLanguage == Language.Chinese ? "Chinese" : "English");
        }
    }
}
