namespace ClaudeVSGui
{
	using System;
	using System.Collections.Generic;
	using System.Text;
	using System.Threading.Tasks;
	using System.Windows;
	using System.Windows.Controls;
	using Markdig;

	public partial class MarkdownChatControl : UserControl
	{
		private MarkdownPipeline pipeline;
		private bool isDarkTheme = true;
		private List<Message> messages = new List<Message>();
		private bool isInitialized = false;

		private class Message
		{
			public string Content { get; set; }
			public bool IsUser { get; set; }
		}

		public MarkdownChatControl()
		{
			InitializeComponent();
			pipeline = new MarkdownPipelineBuilder()
				.UseAdvancedExtensions()
				.Build();

			_ = InitializeAsync();
		}

		private async Task InitializeAsync()
		{
			try
			{
				await ChatWebView.EnsureCoreWebView2Async(null);
				isInitialized = true;
				RenderMessages();
			}
			catch (Exception ex)
			{
				System.Diagnostics.Debug.WriteLine($"WebView2 initialization failed: {ex}");
			}
		}

		public void SetTheme(bool dark)
		{
			isDarkTheme = dark;
			if (isInitialized)
			{
				RenderMessages();
			}
		}

		public void AddUserMessage(string message)
		{
			messages.Add(new Message { Content = message, IsUser = true });
			if (isInitialized)
			{
				RenderMessages();
			}
		}

		public void AddAssistantMessage(string message)
		{
			messages.Add(new Message { Content = message, IsUser = false });
			if (isInitialized)
			{
				RenderMessages();
			}
		}

		public void Clear()
		{
			messages.Clear();
			if (isInitialized)
			{
				RenderMessages();
			}
		}

		private void RenderMessages()
		{
			if (!isInitialized || ChatWebView.CoreWebView2 == null)
				return;

			var html = GenerateHtml();
			ChatWebView.NavigateToString(html);
		}

		private string GenerateHtml()
		{
			var sb = new StringBuilder();

			sb.AppendLine("<!DOCTYPE html>");
			sb.AppendLine("<html>");
			sb.AppendLine("<head>");
			sb.AppendLine("<meta charset='utf-8'>");
			sb.AppendLine("<style>");
			sb.AppendLine(GetCss());
			sb.AppendLine("</style>");
			sb.AppendLine("<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/" +
				(isDarkTheme ? "github-dark" : "github") + ".min.css'>");
			sb.AppendLine("<script src='https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js'></script>");
			sb.AppendLine("<script>hljs.highlightAll();</script>");
			sb.AppendLine("</head>");
			sb.AppendLine("<body>");
			sb.AppendLine("<div class='container'>");

			foreach (var msg in messages)
			{
				string html = Markdig.Markdown.ToHtml(msg.Content, pipeline);
				string cssClass = msg.IsUser ? "message user-message" : "message assistant-message";
				sb.AppendLine($"<div class='{cssClass}'>");
				sb.AppendLine(html);
				sb.AppendLine("</div>");
			}

			sb.AppendLine("</div>");
			sb.AppendLine("<script>window.scrollTo(0, document.body.scrollHeight);</script>");
			sb.AppendLine("</body>");
			sb.AppendLine("</html>");

			return sb.ToString();
		}

		private string GetCss()
		{
			if (isDarkTheme)
			{
				return @"
					body {
						background-color: #1e1e1e;
						color: #d4d4d4;
						font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
						font-size: 13px;
						margin: 0;
						padding: 16px;
					}
					.container {
						max-width: 800px;
						margin: 0 auto;
					}
					.message {
						margin: 8px 0;
						padding: 12px;
						border-radius: 6px;
					}
					.user-message {
						background-color: #2d2d30;
					}
					.assistant-message {
						background-color: #252528;
					}
					pre {
						background-color: #1e1e1e;
						border: 1px solid #3f3f46;
						border-radius: 4px;
						padding: 12px;
						overflow-x: auto;
					}
					code {
						background-color: #2d2d30;
						padding: 2px 6px;
						border-radius: 3px;
						font-family: 'Consolas', 'Courier New', monospace;
					}
					pre code {
						background-color: transparent;
						padding: 0;
					}
					a {
						color: #4fc3f7;
					}
					blockquote {
						border-left: 4px solid #3f3f46;
						margin: 8px 0;
						padding-left: 12px;
						color: #a0a0a0;
					}
					table {
						border-collapse: collapse;
						width: 100%;
						margin: 8px 0;
					}
					th, td {
						border: 1px solid #3f3f46;
						padding: 8px;
						text-align: left;
					}
					th {
						background-color: #2d2d30;
					}
				";
			}
			else
			{
				return @"
					body {
						background-color: #ffffff;
						color: #1e1e1e;
						font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
						font-size: 13px;
						margin: 0;
						padding: 16px;
					}
					.container {
						max-width: 800px;
						margin: 0 auto;
					}
					.message {
						margin: 8px 0;
						padding: 12px;
						border-radius: 6px;
					}
					.user-message {
						background-color: #f5f5f5;
						border: 1px solid #e0e0e0;
					}
					.assistant-message {
						background-color: #ffffff;
						border: 1px solid #e0e0e0;
					}
					pre {
						background-color: #f6f8fa;
						border: 1px solid #d0d7de;
						border-radius: 4px;
						padding: 12px;
						overflow-x: auto;
					}
					code {
						background-color: #f6f8fa;
						padding: 2px 6px;
						border-radius: 3px;
						font-family: 'Consolas', 'Courier New', monospace;
					}
					pre code {
						background-color: transparent;
						padding: 0;
					}
					a {
						color: #0969da;
					}
					blockquote {
						border-left: 4px solid #d0d7de;
						margin: 8px 0;
						padding-left: 12px;
						color: #57606a;
					}
					table {
						border-collapse: collapse;
						width: 100%;
						margin: 8px 0;
					}
					th, td {
						border: 1px solid #d0d7de;
						padding: 8px;
						text-align: left;
					}
					th {
						background-color: #f6f8fa;
					}
				";
			}
		}
	}
}
