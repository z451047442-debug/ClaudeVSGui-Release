using System.Windows;
using System.Windows.Controls;

namespace ClaudeVSGui
{
    public partial class CommandInputDialog : Window
    {
        public string CommandName { get; private set; }

        public CommandInputDialog(string defaultCommand)
        {
            InitializeComponent();
            UpdateLanguage();
            CommandTextBox.Text = defaultCommand;
            CommandTextBox.Focus();
            CommandTextBox.SelectAll();
        }

        private void UpdateLanguage()
        {
            Title = LanguageManager.Get("EnterCommand");
            if (SelectPresetLabel != null)
                SelectPresetLabel.Text = LanguageManager.Get("SelectPreset");
            if (OrEnterCommandLabel != null)
                OrEnterCommandLabel.Text = LanguageManager.Get("OrEnterCommand");
            if (OkButton != null)
                OkButton.Content = LanguageManager.Get("OK");
            if (CancelButton != null)
                CancelButton.Content = LanguageManager.Get("Cancel");
        }

        private void CommandPresetCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CommandPresetCombo.SelectedItem is ComboBoxItem selectedItem)
            {
                string value = selectedItem.Tag?.ToString() ?? selectedItem.Content.ToString();
                CommandTextBox.Text = value;
            }
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            CommandName = CommandTextBox.Text;
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}