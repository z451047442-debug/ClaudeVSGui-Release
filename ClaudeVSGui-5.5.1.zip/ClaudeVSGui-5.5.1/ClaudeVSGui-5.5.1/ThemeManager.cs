namespace ClaudeVSGui
{
	using System;
	using System.Diagnostics;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Media;
	using Microsoft.Terminal.Wpf;
	using Microsoft.VisualStudio.Shell;

	public partial class ClaudeTerminalControl
	{
		private void FontSizeButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var dialog = new FontSizeDialog(currentFontSize);
				dialog.Owner = Application.Current?.MainWindow;
				if (dialog.ShowDialog() == true)
				{
					short newFontSize = dialog.SelectedFontSize;
					if (newFontSize != currentFontSize)
					{
						currentFontSize = newFontSize;
						SettingsManager.SaveFontSize(currentFontSize);
						ApplyFontSizeToAll();
					}
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in FontSizeButton_Click: {ex}");
			}
		}

		private void ApplyFontSize(AgentTab tab)
		{
			try
			{
				var theme = GetTerminalTheme();
				var bgColor = GetThemeBackgroundColor();
				tab.TerminalControl.SetTheme(theme, "Consolas", currentFontSize, bgColor);
				tab.TerminalControl.Background = new SolidColorBrush(bgColor);
				this.Background = new SolidColorBrush(bgColor);
				AgentTabs.Background = new SolidColorBrush(bgColor);
				UpdateToolbarColors();

				UpdateTerminalMaxWidth(tab);

				if (tab.TerminalControl.ActualHeight > 0 && tab.TerminalControl.ActualWidth > 0)
				{
					var size = new Size(tab.TerminalControl.ActualWidth, tab.TerminalControl.ActualHeight);
					tab.TerminalControl.TriggerResize(size);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ApplyFontSize: {ex}");
			}
		}

		private void ApplyFontSizeToAll()
		{
			foreach (var tab in agentTabs)
			{
				ApplyFontSize(tab);
			}
		}

		private void UpdateTerminalMaxWidth(AgentTab tab)
		{
			// typically, it's +80 Width per font size but there's a trap at 16 where it's +3 compared to 14 and so requires + (3 * 80) instead of + (2 * 80)
			if (currentFontSize == 8)
				tab.TerminalBorder.Width = 740.0;
			else if (currentFontSize == 9)
				tab.TerminalBorder.Width = 820.0;
			else if (currentFontSize == 10)
				tab.TerminalBorder.Width = 900.0;
			else if (currentFontSize == 11)
				tab.TerminalBorder.Width = 980.0;
			else if (currentFontSize == 12)
				tab.TerminalBorder.Width = 1060.0;
			else if (currentFontSize == 14)
				tab.TerminalBorder.Width = 1220.0;
			else if (currentFontSize == 16)
				tab.TerminalBorder.Width = 1460.0;
			else if (currentFontSize == 18)
				tab.TerminalBorder.Width = 1620.0;
			else if (currentFontSize == 20)
				tab.TerminalBorder.Width = 1780.0;
			else if (currentFontSize == 24)
				tab.TerminalBorder.Width = 2100.0;
		}

		private void ThemeButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var dialog = new ThemeDialog(currentTheme);
				dialog.Owner = Application.Current?.MainWindow;
				if (dialog.ShowDialog() == true)
				{
					string newTheme = dialog.SelectedTheme;
					if (newTheme != currentTheme)
					{
						currentTheme = newTheme;
						SettingsManager.SaveTheme(currentTheme);
						foreach (var tab in agentTabs)
						{
							tab.NeedsResizeAfterOutput = true;
							string projectDir = GetActiveProjectDirectory();
							if (!string.IsNullOrEmpty(projectDir))
							{
								tab.CurrentSolutionPath = projectDir;
								RestartClaudeWithWorkingDirectory(tab, projectDir);
							}
							else
							{
								tab.CurrentSolutionPath = null;
								StopClaude(tab);
								InitializeConPtyTerminal(tab);
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ThemeButton_Click: {ex}");
			}
		}

		private void ApplyTheme(AgentTab tab)
		{
			try
			{
				var theme = GetTerminalTheme();
				var bgColor = GetThemeBackgroundColor();
				tab.TerminalControl.SetTheme(theme, "Consolas", currentFontSize, bgColor);
				tab.TerminalControl.Background = new SolidColorBrush(bgColor);
				this.Background = new SolidColorBrush(bgColor);
				UpdateToolbarColors();

				if (tab.TerminalControl.ActualHeight > 0 && tab.TerminalControl.ActualWidth > 0)
				{
					var size = new Size(tab.TerminalControl.ActualWidth, tab.TerminalControl.ActualHeight);
					tab.TerminalControl.TriggerResize(size);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ApplyTheme: {ex}");
			}
		}

		private void ApplyThemeToAll()
		{
			foreach (var tab in agentTabs)
			{
				ApplyTheme(tab);
			}
		}

		private Color GetThemeBackgroundColor()
		{
			string effectiveTheme = currentTheme;
			if (effectiveTheme == "System")
			{
				effectiveTheme = IsSystemDarkMode() ? "Dark" : "Light";
			}

			if (effectiveTheme == "Light")
			{
				return Color.FromRgb(0xFF, 0xFF, 0xFF);
			}
			else
			{
				return Color.FromRgb(0x1e, 0x1e, 0x1e);
			}
		}

		private void UpdateToolbarColors()
		{
			string effectiveTheme = currentTheme;
			if (effectiveTheme == "System")
			{
				effectiveTheme = IsSystemDarkMode() ? "Dark" : "Light";
			}

			SolidColorBrush toolbarBg, buttonBg, buttonFg, buttonBorder;

			if (effectiveTheme == "Light")
			{
				toolbarBg = new SolidColorBrush(Color.FromRgb(0xE8, 0xE8, 0xE8));
				buttonBg = new SolidColorBrush(Color.FromRgb(0xF5, 0xF5, 0xF5));
				buttonFg = new SolidColorBrush(Color.FromRgb(0x1E, 0x1E, 0x1E));
				buttonBorder = new SolidColorBrush(Color.FromRgb(0xF5, 0xF5, 0xF5));

				MicButton.Style = (Style)FindResource("LightToggleButtonStyle");
				ViewModeButton.Style = (Style)FindResource("LightToggleButtonStyle");
				ChangeCommandButton.Style = (Style)FindResource("LightButtonStyle");
				RestartAgentButton.Style = (Style)FindResource("LightButtonStyle");
				NewAgentButton.Style = (Style)FindResource("LightButtonStyle");
				ThemeButton.Style = (Style)FindResource("LightButtonStyle");
				FontSizeButton.Style = (Style)FindResource("LightButtonStyle");
				QuickSwitchButton.Style = (Style)FindResource("LightButtonStyle");
				SendImageButton.Style = (Style)FindResource("LightButtonStyle");
				LanguageButton.Style = (Style)FindResource("LightButtonStyle");
				SettingsButton.Style = (Style)FindResource("LightButtonStyle");
			}
			else
			{
				toolbarBg = new SolidColorBrush(Color.FromRgb(0x0C, 0x0C, 0x0C));
				buttonBg = new SolidColorBrush(Color.FromRgb(0x1E, 0x1E, 0x1E));
				buttonFg = new SolidColorBrush(Color.FromRgb(0xD4, 0xD4, 0xD4));
				buttonBorder = new SolidColorBrush(Color.FromRgb(0x1E, 0x1E, 0x1E));

				MicButton.Style = (Style)FindResource("DarkToggleButtonStyle");
				ViewModeButton.Style = (Style)FindResource("DarkToggleButtonStyle");
				ChangeCommandButton.Style = (Style)FindResource("DarkButtonStyle");
				RestartAgentButton.Style = (Style)FindResource("DarkButtonStyle");
				NewAgentButton.Style = (Style)FindResource("DarkButtonStyle");
				ThemeButton.Style = (Style)FindResource("DarkButtonStyle");
				FontSizeButton.Style = (Style)FindResource("DarkButtonStyle");
				QuickSwitchButton.Style = (Style)FindResource("DarkButtonStyle");
				SendImageButton.Style = (Style)FindResource("DarkButtonStyle");
				LanguageButton.Style = (Style)FindResource("DarkButtonStyle");
				SettingsButton.Style = (Style)FindResource("DarkButtonStyle");
			}

			ToolbarBorder.Background = toolbarBg;
			BottomToolbarBorder.Background = toolbarBg;

			MicButton.Background = buttonBg;
			MicButton.Foreground = buttonFg;
			MicButton.BorderBrush = buttonBorder;

			ViewModeButton.Background = buttonBg;
			ViewModeButton.Foreground = buttonFg;
			ViewModeButton.BorderBrush = buttonBorder;

			ChangeCommandButton.Background = buttonBg;
			ChangeCommandButton.Foreground = buttonFg;
			ChangeCommandButton.BorderBrush = buttonBorder;

			RestartAgentButton.Background = buttonBg;
			RestartAgentButton.Foreground = buttonFg;
			RestartAgentButton.BorderBrush = buttonBorder;

			NewAgentButton.Background = buttonBg;
			NewAgentButton.Foreground = buttonFg;
			NewAgentButton.BorderBrush = buttonBorder;

			ThemeButton.Background = buttonBg;
			ThemeButton.Foreground = buttonFg;
			ThemeButton.BorderBrush = buttonBorder;

			FontSizeButton.Background = buttonBg;
			FontSizeButton.Foreground = buttonFg;
			FontSizeButton.BorderBrush = buttonBorder;

			QuickSwitchButton.Background = buttonBg;
			QuickSwitchButton.Foreground = buttonFg;
			QuickSwitchButton.BorderBrush = buttonBorder;

			SendImageButton.Background = buttonBg;
			SendImageButton.Foreground = buttonFg;
			SendImageButton.BorderBrush = buttonBorder;

			LanguageButton.Background = buttonBg;
			LanguageButton.Foreground = buttonFg;
			LanguageButton.BorderBrush = buttonBorder;

			SettingsButton.Background = buttonBg;
			SettingsButton.Foreground = buttonFg;
			SettingsButton.BorderBrush = buttonBorder;

			var tabItemStyle = (Style)FindResource(effectiveTheme == "Light" ? "LightTabItemStyle" : "DarkTabItemStyle");
			var closeButtonStyle = (Style)FindResource(effectiveTheme == "Light" ? "LightTabCloseButtonStyle" : "DarkTabCloseButtonStyle");
			foreach (var tab in agentTabs)
			{
				tab.TabItem.Style = tabItemStyle;
				var headerPanel = tab.TabItem.Header as StackPanel;
				if (headerPanel != null && headerPanel.Children.Count >= 2)
				{
					var closeButton = headerPanel.Children[1] as Button;
					if (closeButton != null)
					{
						closeButton.Style = closeButtonStyle;
					}
				}
			}
		}

		private TerminalTheme GetTerminalTheme()
		{
			string effectiveTheme = currentTheme;
			if (effectiveTheme == "System")
			{
				effectiveTheme = IsSystemDarkMode() ? "Dark" : "Light";
			}

			if (effectiveTheme == "Light")
			{
				return new TerminalTheme
				{
					DefaultBackground = 0xFFFFFFFF,
					DefaultForeground = 0xFF000000,
					DefaultSelectionBackground = 0xFF0078D7,
					CursorStyle = CursorStyle.BlinkingBar,
					ColorTable = new uint[]
					{
						0xFFFFFFFF, 0xFFC50F1F, 0xFF13A10E, 0xFFC19C00,
						0xFF0037DA, 0xFF881798, 0xFF3A96DD, 0xFF000000,
						0xFFFFFFFF, 0xFFE74856, 0xFF16C60C, 0xFFF9F1A5,
						0xFF3B78FF, 0xFFB4009E, 0xFF61D6D6, 0xFF000000
					}
				};
			}
			else
			{
				return new TerminalTheme
				{
					DefaultBackground = 0xFF1e1e1e,
					DefaultForeground = 0xFFd4d4d4,
					DefaultSelectionBackground = 0xFF264F78,
					CursorStyle = CursorStyle.BlinkingBar,
					ColorTable = new uint[]
					{
						0xFF1e1e1e, 0xFFC50F1F, 0xFF13A10E, 0xFFC19C00,
						0xFF0037DA, 0xFF881798, 0xFF3A96DD, 0xFFCCCCCC,
						0xFF1e1e1e, 0xFFE74856, 0xFF16C60C, 0xFFF9F1A5,
						0xFF3B78FF, 0xFFB4009E, 0xFF61D6D6, 0xFFF2F2F2
					}
				};
			}
		}

		private bool IsSystemDarkMode()
		{
			try
			{
				using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"))
				{
					if (key != null)
					{
						var value = key.GetValue("AppsUseLightTheme");
						if (value is int intValue)
						{
							return intValue == 0;
						}
					}
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in IsSystemDarkMode: {ex}");
			}
			return true;
		}
	}
}
