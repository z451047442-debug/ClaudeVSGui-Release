namespace ClaudeVSGui
{
	using System;
	using System.Diagnostics;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Controls.Primitives;
	using System.Windows.Input;
	using System.Windows.Media;
	using EnvDTE80;
	using Microsoft.VisualStudio.Shell;

	public partial class ClaudeTerminalControl
	{
		private void UpdateQuickSwitchVisibility()
		{
			QuickSwitchButton.Visibility = IsClaudeAgent() ? Visibility.Visible : Visibility.Collapsed;
		}

		private bool IsClaudeAgent()
		{
			string cmd = activeTab?.Command ?? currentCommand;
			return cmd != null && cmd.IndexOf("claude", StringComparison.OrdinalIgnoreCase) >= 0;
		}

		private void QuickSwitchButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				if (activeTab?.Terminal != null && activeTab.Terminal.IsRunning)
				{
					if (quickSwitchPopup != null && quickSwitchPopup.IsOpen)
					{
						quickSwitchPopup.IsOpen = false;
						return;
					}

					string effectiveTheme = currentTheme;
					if (effectiveTheme == "System")
						effectiveTheme = IsSystemDarkMode() ? "Dark" : "Light";
					bool isDark = effectiveTheme != "Light";

					var bgBrush = isDark
						? new SolidColorBrush(Color.FromRgb(0x2D, 0x2D, 0x30))
						: new SolidColorBrush(Color.FromRgb(0xF5, 0xF5, 0xF5));
					var borderBrush = isDark
						? new SolidColorBrush(Color.FromRgb(0x3F, 0x3F, 0x46))
						: new SolidColorBrush(Color.FromRgb(0xCC, 0xCC, 0xCC));
					var fgBrush = isDark
						? new SolidColorBrush(Color.FromRgb(0xD4, 0xD4, 0xD4))
						: new SolidColorBrush(Color.FromRgb(0x1E, 0x1E, 0x1E));

					var popup = new Popup
					{
						StaysOpen = false,
						AllowsTransparency = true,
						PlacementTarget = QuickSwitchButton,
						Placement = PlacementMode.Bottom,
					};

					var outerBorder = new Border
					{
						Background = bgBrush,
						BorderBrush = borderBrush,
						BorderThickness = new Thickness(1),
						Padding = new Thickness(8),
					};

					var grid = new Grid();
					grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
					grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
					grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
					grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
					grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

					for (int i = 0; i < 5; i++)
						grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

					var headerMargin = new Thickness(4, 2, 4, 6);

					var hModel = new TextBlock { Text = "Model", Foreground = fgBrush, Margin = headerMargin, FontWeight = FontWeights.Bold };
					Grid.SetRow(hModel, 0); Grid.SetColumn(hModel, 1);
					grid.Children.Add(hModel);

					var hThinking = new TextBlock { Text = "Thinking", Foreground = fgBrush, Margin = headerMargin, FontWeight = FontWeights.Bold };
					Grid.SetRow(hThinking, 0); Grid.SetColumn(hThinking, 2);
					grid.Children.Add(hThinking);

					var hEffort = new TextBlock { Text = "Effort", Foreground = fgBrush, Margin = headerMargin, FontWeight = FontWeights.Bold };
					Grid.SetRow(hEffort, 0); Grid.SetColumn(hEffort, 3);
					grid.Children.Add(hEffort);

					string[] quickSwitchCommandNames = {
						"ClaudeVSGui.QuickSwitch1",
						"ClaudeVSGui.QuickSwitch2",
						"ClaudeVSGui.QuickSwitch3",
						"ClaudeVSGui.QuickSwitch4"
					};
					string[] quickSwitchHotkeys = new string[4];
					try
					{
						DTE2 localDte = dte ?? GetDTE();
						if (localDte != null)
						{
							for (int i = 0; i < 4; i++)
							{
								try
								{
									var cmd = localDte.Commands.Item(quickSwitchCommandNames[i]);
									var bindings = cmd.Bindings as object[];
									if (bindings != null && bindings.Length > 0)
									{
										string b = bindings[0].ToString();
										int idx = b.IndexOf("::");
										quickSwitchHotkeys[i] = idx >= 0 ? b.Substring(idx + 2) : b;
									}
								}
								catch { }
							}
						}
					}
					catch { }

					string[] models = { "Opus 4.6", "Sonnet 4.6", "Haiku 4.5" };
					string[] efforts = { "Low", "Medium", "High", "Max", "Auto" };

					for (int row = 0; row < 4; row++)
					{
						int capturedRow = row;
						int rowIndex = row + 1;
						var cellMargin = new Thickness(4, 2, 4, 2);

						var modelCombo = new ComboBox { Margin = cellMargin, MinWidth = 100 };
						foreach (var m in models)
							modelCombo.Items.Add(m);
						modelCombo.SelectedIndex = quickSwitchPresetModel[row];

						var thinkingCheck = new CheckBox
						{
							Margin = cellMargin,
							VerticalAlignment = VerticalAlignment.Center,
							HorizontalAlignment = HorizontalAlignment.Center,
							IsChecked = quickSwitchPresetThinking[row]
						};

						var effortCombo = new ComboBox { Margin = cellMargin, MinWidth = 80 };
						foreach (var ef in efforts)
							effortCombo.Items.Add(ef);
						effortCombo.SelectedIndex = quickSwitchPresetEffort[row];
						effortCombo.Visibility = modelCombo.SelectedIndex == 0 ? Visibility.Visible : Visibility.Hidden;

						var capturedEffortCombo = effortCombo;
						var capturedModelCombo = modelCombo;
						modelCombo.SelectionChanged += (s, ev) =>
						{
							capturedEffortCombo.Visibility = capturedModelCombo.SelectedIndex == 0 ? Visibility.Visible : Visibility.Hidden;
							quickSwitchPresetModel[capturedRow] = capturedModelCombo.SelectedIndex;
							SettingsManager.SaveQuickSwitchPresets(quickSwitchPresetModel, quickSwitchPresetThinking, quickSwitchPresetEffort);
						};

						var capturedThinkingCheck = thinkingCheck;
						thinkingCheck.Checked += (s, ev) =>
						{
							quickSwitchPresetThinking[capturedRow] = true;
							SettingsManager.SaveQuickSwitchPresets(quickSwitchPresetModel, quickSwitchPresetThinking, quickSwitchPresetEffort);
						};
						thinkingCheck.Unchecked += (s, ev) =>
						{
							quickSwitchPresetThinking[capturedRow] = false;
							SettingsManager.SaveQuickSwitchPresets(quickSwitchPresetModel, quickSwitchPresetThinking, quickSwitchPresetEffort);
						};

						effortCombo.SelectionChanged += (s, ev) =>
						{
							quickSwitchPresetEffort[capturedRow] = capturedEffortCombo.SelectedIndex;
							SettingsManager.SaveQuickSwitchPresets(quickSwitchPresetModel, quickSwitchPresetThinking, quickSwitchPresetEffort);
						};
						var selectButton = new Button
						{
							Content = "▶",
							Margin = cellMargin,
							Padding = new Thickness(6, 2, 6, 2),
							Cursor = Cursors.Hand,
						};
						selectButton.Click += (s, ev) =>
						{
							quickSwitchPresetModel[capturedRow] = capturedModelCombo.SelectedIndex;
							quickSwitchPresetThinking[capturedRow] = capturedThinkingCheck.IsChecked == true;
							quickSwitchPresetEffort[capturedRow] = capturedEffortCombo.SelectedIndex;
							popup.IsOpen = false;
							ExecuteQuickSwitch(capturedRow);
						};

						Grid.SetRow(selectButton, rowIndex); Grid.SetColumn(selectButton, 0);
						Grid.SetRow(modelCombo, rowIndex); Grid.SetColumn(modelCombo, 1);
						Grid.SetRow(thinkingCheck, rowIndex); Grid.SetColumn(thinkingCheck, 2);
						Grid.SetRow(effortCombo, rowIndex); Grid.SetColumn(effortCombo, 3);

						if (!string.IsNullOrEmpty(quickSwitchHotkeys[capturedRow]))
						{
							var hotkeyLabel = new TextBlock
							{
								Text = quickSwitchHotkeys[capturedRow],
								Foreground = fgBrush,
								Margin = cellMargin,
								VerticalAlignment = VerticalAlignment.Center,
								Opacity = 0.6,
							};
							Grid.SetRow(hotkeyLabel, rowIndex); Grid.SetColumn(hotkeyLabel, 4);
							grid.Children.Add(hotkeyLabel);
						}

						grid.Children.Add(selectButton);
						grid.Children.Add(modelCombo);
						grid.Children.Add(thinkingCheck);
						grid.Children.Add(effortCombo);
					}

					outerBorder.Child = grid;
					popup.Child = outerBorder;
					quickSwitchPopup = popup;
					popup.IsOpen = true;
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in QuickSwitchButton_Click: {ex}");
			}
		}

		public void ExecuteQuickSwitch(int presetIndex)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			if (!IsClaudeAgent()) return;
			if (quickSwitchInProgress) return;
			if (presetIndex < 0 || presetIndex > 3) return;
			if (activeTab?.Terminal == null || !activeTab.Terminal.IsRunning) return;
			quickSwitchInProgress = true;

			iTargetModel = quickSwitchPresetModel[presetIndex];
			bThinking = quickSwitchPresetThinking[presetIndex];
			iTargetEffort = quickSwitchPresetEffort[presetIndex];

			SettingsManager.SaveQuickSwitchPresets(quickSwitchPresetModel, quickSwitchPresetThinking, quickSwitchPresetEffort);

			var terminal = activeTab.Terminal;
			var tab = activeTab;
			_ = System.Threading.Tasks.Task.Run(async () =>
			{
				try
				{
					ClearRecentTranscript(tab);
					terminal.WriteInput("\x1bt");
					await System.Threading.Tasks.Task.Delay(200);
					terminal.WriteInput(bThinking ? "1" : "2");
					await System.Threading.Tasks.Task.Delay(200);

					if (RecentTranscriptContains(tab, "Do you want to proceed?"))
					{
						terminal.WriteInput("\r");
						await System.Threading.Tasks.Task.Delay(200);
					}

					string[] modelIds = { "claude-opus-4-6", "claude-sonnet-4-6", "claude-haiku-4-5" };
					ClearRecentTranscript(tab);
					terminal.WriteInput("/model " + modelIds[iTargetModel]);
					await System.Threading.Tasks.Task.Delay(200);
					terminal.WriteInput("\r");

					if (iTargetModel == 0)
					{
						string[] effortLevels = { "low", "medium", "high", "max", "auto" };
						for (int wait = 0; wait < 50; wait++)
						{
							await System.Threading.Tasks.Task.Delay(200);
							if (RecentTranscriptContains(tab, "Set model to "))
								break;
						}
						terminal.WriteInput("/effort " + effortLevels[iTargetEffort]);
						await System.Threading.Tasks.Task.Delay(200);
						terminal.WriteInput("\r");
					}
				}
				finally
				{
					quickSwitchInProgress = false;
				}
			});
		}
	}
}
