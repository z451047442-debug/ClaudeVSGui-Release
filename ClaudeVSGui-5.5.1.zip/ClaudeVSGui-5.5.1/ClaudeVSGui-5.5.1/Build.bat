@echo off
setlocal

set "CONFIG=%~1"
if "%CONFIG%"=="" set "CONFIG=Debug"

for /f "usebackq delims=" %%i in (`powershell -NoProfile -Command "$vw=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'; if(!(Test-Path $vw)){$vw=Join-Path $env:ProgramFiles 'Microsoft Visual Studio\Installer\vswhere.exe'}; & $vw -latest -prerelease -requires Microsoft.Component.MSBuild -find 'MSBuild\**\Bin\MSBuild.exe' | Select-Object -First 1"`) do set "MSBUILD=%%i"

if not defined MSBUILD (
  echo ERROR: MSBuild not found.
  exit /b 1
)

echo Using MSBuild: %MSBUILD%
echo Configuration: %CONFIG%
"%MSBUILD%" "%~dp0ClaudeVSGui.csproj" -t:Build -p:Configuration=%CONFIG% -v:minimal
exit /b %ERRORLEVEL%