namespace ClaudeVSGui
{
	using System;
	using System.Diagnostics;
	using System.Windows.Controls;
	using System.Windows.Media;
	using Microsoft.Terminal.Wpf;
	using Microsoft.VisualStudio.Shell;

	public partial class ClaudeTerminalControl
	{
		private void InitializeConPtyTerminal(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			InitializeConPtyTerminal(tab, null);
		}

		private void InitializeConPtyTerminal(AgentTab tab, string workingDirectory)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var conPtyTerminal = new ConPtyTerminal(rows: 30, columns: 120);
				conPtyTerminal.Command = tab.Command ?? currentCommand;

				string workingDir = string.IsNullOrEmpty(workingDirectory) ? GetActiveProjectDirectory() : workingDirectory;
				if (string.IsNullOrEmpty(workingDir))
				{
					workingDir = System.Environment.GetFolderPath(System.Environment.SpecialFolder.UserProfile);
				}

				bool initialized = conPtyTerminal.Initialize(workingDir);

				if (!initialized)
				{
					conPtyTerminal?.Dispose();
					return;
				}

				var terminalConnection = new ConPtyTerminalConnection(conPtyTerminal);

				tab.OutputReceivedHandler = (sender, output) => ConPtyTerminal_OutputReceived(tab, output);
				conPtyTerminal.OutputReceived += tab.OutputReceivedHandler;

				terminalConnection.WaitForConnectionReady();

				tab.Terminal = conPtyTerminal;
				tab.Connection = terminalConnection;
				tab.TerminalControl.Connection = terminalConnection;

				ExtractTerminalHandle(tab);

				var theme = GetTerminalTheme();
				var bgColor = GetThemeBackgroundColor();
				tab.TerminalControl.SetTheme(theme, "Consolas", currentFontSize, bgColor);
				tab.TerminalControl.Background = new SolidColorBrush(bgColor);
				this.Background = new SolidColorBrush(bgColor);
				AgentTabs.Background = new SolidColorBrush(bgColor);
				UpdateToolbarColors();

				UpdateTerminalMaxWidth(tab);

				terminalConnection.Start();

				tab.TerminalControl.SetTheme(theme, "Consolas", currentFontSize, bgColor);

				tab.NeedsResizeAfterOutput = true;
				tab.IsInitialized = true;
				tab.CurrentSolutionPath = workingDir;
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in InitializeConPtyTerminal: {ex}");
			}
		}

		private void RestartClaudeWithWorkingDirectory(AgentTab tab, string workingDirectory)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				StopClaude(tab);
				InitializeConPtyTerminal(tab, workingDirectory);
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in RestartClaudeWithWorkingDirectory: {ex}");
			}
		}

		private void StopClaude()
		{
			try
			{
				foreach (var tab in agentTabs)
				{
					StopClaude(tab);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in StopClaude: {ex}");
			}
		}

		private void StopClaude(AgentTab tab)
		{
			try
			{
				tab.RefreshTimer?.Stop();
				tab.SelectionScrollTimer?.Stop();
				tab.TerminalControl.Connection = null;
				if (tab.Terminal != null && tab.OutputReceivedHandler != null)
				{
					tab.Terminal.OutputReceived -= tab.OutputReceivedHandler;
					tab.OutputReceivedHandler = null;
				}
				tab.Connection?.Dispose();
				tab.Terminal?.Dispose();
				tab.Connection = null;
				tab.Terminal = null;
				tab.TerminalHandle = IntPtr.Zero;
				tab.TerminalHwnd = IntPtr.Zero;
				tab.IsInitialized = false;
				lock (tab.TranscriptLock)
				{
					tab.RecentTranscript.Clear();
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in StopClaude(AgentTab): {ex}");
			}
		}

		public void DisposeAllTerminals()
		{
			StopClaude();
		}
	}
}
