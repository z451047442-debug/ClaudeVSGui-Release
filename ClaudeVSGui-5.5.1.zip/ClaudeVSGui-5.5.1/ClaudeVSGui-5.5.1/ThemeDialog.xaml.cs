using System.Windows;
using System.Windows.Controls;

namespace ClaudeVSGui
{
    public partial class ThemeDialog : Window
    {
        public string SelectedTheme { get; private set; }

        public ThemeDialog(string currentTheme)
        {
            InitializeComponent();
            UpdateLanguage();
            SelectedTheme = currentTheme;
            SelectTheme(currentTheme);
        }

        private void UpdateLanguage()
        {
            Title = LanguageManager.Get("SelectTheme");
            if (SelectThemeLabel != null)
                SelectThemeLabel.Text = LanguageManager.Get("SelectThemeLabel");
            if (OkButton != null)
                OkButton.Content = LanguageManager.Get("OK");
            if (CancelButton != null)
                CancelButton.Content = LanguageManager.Get("Cancel");

            if (ThemeCombo != null)
            {
                foreach (ComboBoxItem item in ThemeCombo.Items)
                {
                    string tag = item.Tag?.ToString();
                    if (tag == "System")
                        item.Content = LanguageManager.Get("System");
                    else if (tag == "Light")
                        item.Content = LanguageManager.Get("Light");
                    else if (tag == "Dark")
                        item.Content = LanguageManager.Get("Dark");
                }
            }
        }

        private void SelectTheme(string theme)
        {
            foreach (ComboBoxItem item in ThemeCombo.Items)
            {
                if (item.Tag?.ToString() == theme)
                {
                    ThemeCombo.SelectedItem = item;
                    return;
                }
            }
            ThemeCombo.SelectedIndex = 0;
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (ThemeCombo.SelectedItem is ComboBoxItem selectedItem)
            {
                SelectedTheme = selectedItem.Tag?.ToString() ?? "System";
            }
            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
