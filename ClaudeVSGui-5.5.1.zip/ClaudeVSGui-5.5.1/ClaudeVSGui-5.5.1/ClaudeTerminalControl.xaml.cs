namespace ClaudeVSGui
{
	using System;
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.IO;
	using System.Reflection;
	using System.Runtime.InteropServices;
	using System.Text;
	using System.Windows.Threading;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Input;
	using System.Windows.Interop;
	using System.Windows.Media;
	using System.Windows.Controls.Primitives;
	using EnvDTE;
	using EnvDTE80;
	using Microsoft.Terminal.Wpf;
	using Microsoft.VisualStudio.Shell;
	using Microsoft.VisualStudio.Shell.Interop;

	/// <summary>
	/// Interaction logic for ClaudeTerminalControl.xaml
	/// </summary>
	public partial class ClaudeTerminalControl : UserControl
	{
		[DllImport("user32.dll")]
		private static extern IntPtr SetFocus(IntPtr hWnd);

		[DllImport("Microsoft.Terminal.Control.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall, PreserveSig = true)]
		[return: MarshalAs(UnmanagedType.I1)]
		private static extern bool TerminalIsSelectionActive(IntPtr terminal);

		[DllImport("Microsoft.Terminal.Control.dll", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.StdCall, PreserveSig = true)]
		private static extern void TerminalUserScroll(IntPtr terminal, int viewTop);

		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool GetCursorPos(out POINT lpPoint);

		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		private static extern IntPtr SendMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

		[DllImport("user32.dll")]
		private static extern short GetAsyncKeyState(int vKey);

		private const int VK_LBUTTON = 0x01;
		private const uint WM_MOUSEWHEEL = 0x020A;
		private const int WHEEL_DELTA = 120;
		private const int MK_LBUTTON = 0x0001;
		private const int WM_LBUTTONDOWN = 0x0201;
		private const int QuickSwitchTranscriptLimit = 16384;

		[StructLayout(LayoutKind.Sequential)]
		private struct POINT
		{
			public int X;
			public int Y;
		}



		private ClaudeTerminal claudeTerminal;
		private DTE2 dte;
		private SolutionEvents solutionEvents;
		private string currentCommand = "claude";
		private short currentFontSize = 10;
		private string currentTheme = "System";
		private int nextTabIndex = 1;
		private List<AgentTab> agentTabs = new List<AgentTab>();
		private AgentTab activeTab;
		private AgentTab lastUserSelectedTab;
		private Popup quickSwitchPopup;
		private bool quickSwitchInProgress;
		private int iTargetModel;
		private bool bThinking;
		private int iTargetEffort;
		private int[] quickSwitchPresetModel = { 0, 1, 2, 2 };
		private bool[] quickSwitchPresetThinking = { false, false, false, false };
		private int[] quickSwitchPresetEffort = { 0, 0, 0, 0 };
		private bool eventsInitialized;
		private bool isMarkdownMode = false;
		private System.Text.StringBuilder currentAssistantMessage = new System.Text.StringBuilder();
		private bool isCollectingAssistantMessage = false;

		/// <summary>
		/// Initializes a new instance of the <see cref="ClaudeTerminalControl"/> class.
		/// </summary>
		public ClaudeTerminalControl(ToolWindowPane toolWindowPane = null)
		{
			this.claudeTerminal = toolWindowPane as ClaudeTerminal;
			this.InitializeComponent();
			this.Loaded += ClaudeTerminalControl_Loaded;
			this.Unloaded += ClaudeTerminalControl_Unloaded;
			this.SizeChanged += ClaudeTerminalControl_SizeChanged;
			this.IsVisibleChanged += ClaudeTerminalControl_IsVisibleChanged;
			AgentTabs.GotKeyboardFocus += AgentTabs_GotKeyboardFocus;
		}

		private void ClaudeTerminalControl_Loaded(object sender, System.Windows.RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				LanguageManager.LoadLanguage();
				currentCommand = SettingsManager.GetLastCommand();
				currentFontSize = SettingsManager.GetFontSize();
				currentTheme = SettingsManager.GetTheme();
				SettingsManager.LoadQuickSwitchPresets(quickSwitchPresetModel, quickSwitchPresetThinking, quickSwitchPresetEffort);

				UpdateLanguage();

				if (agentTabs.Count == 0)
				{
					CreateNewAgentTab(false);
				}

				UpdateTabVisibility();

				if (activeTab == null)
				{
					SetActiveTab(agentTabs[0]);
				}
				else if (lastUserSelectedTab == null)
				{
					lastUserSelectedTab = activeTab;
				}

				if (!eventsInitialized)
				{
					dte = GetDTE();
					if (dte != null && dte.Events != null)
					{
						solutionEvents = dte.Events.SolutionEvents;
						if (solutionEvents != null)
						{
							solutionEvents.Opened += SolutionEvents_Opened;
							solutionEvents.AfterClosing += SolutionEvents_AfterClosing;
						}
					}
					eventsInitialized = true;
				}

				EnsureTabInitialized(activeTab);
				ApplyThemeToAll();
				ApplyFontSizeToAll();
				FocusTerminal();
				_ = QueueDeferredLayoutUpdateAsync();
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ClaudeTerminalControl_Loaded: {ex}");
			}
		}

		private async System.Threading.Tasks.Task QueueDeferredLayoutUpdateAsync()
		{
			await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
			try
			{
				if (activeTab != null)
				{
					ApplyFontSize(activeTab);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in deferred layout: {ex}");
			}
		}

		private void QueueDeferredLayoutUpdate()
		{
			_ = QueueDeferredLayoutUpdateAsync();
		}

		private void ReconnectTerminal()
		{
			try
			{
				if (activeTab?.Connection != null)
				{
					activeTab.TerminalControl.Connection = activeTab.Connection;
					activeTab.TerminalControl.InvalidateVisual();
					activeTab.TerminalControl.UpdateLayout();
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ReconnectTerminal: {ex}");
			}
		}

		private void ClaudeTerminalControl_SizeChanged(object sender, System.Windows.SizeChangedEventArgs e)
		{
			try
			{
				if (activeTab == null)
				{
					return;
				}
				var terminalConnection = activeTab.Connection;
				if (terminalConnection != null && activeTab.TerminalControl.ActualHeight > 0 && activeTab.TerminalControl.ActualWidth > 0)
				{
					double charHeight = currentFontSize * 1.2;

					uint columns = 120;
					uint rows = (uint)Math.Max(1, activeTab.TerminalControl.ActualHeight / charHeight);

					terminalConnection.Resize(rows, columns);

					var size = new Size(activeTab.TerminalControl.ActualWidth, activeTab.TerminalControl.ActualHeight);
					activeTab.TerminalControl.TriggerResize(size);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ClaudeTerminalControl_SizeChanged: {ex}");
			}
		}

		private void ClaudeTerminalControl_Unloaded(object sender, System.Windows.RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				if (solutionEvents != null)
				{
					try { solutionEvents.Opened -= SolutionEvents_Opened; } catch { }
					try { solutionEvents.AfterClosing -= SolutionEvents_AfterClosing; } catch { }
					solutionEvents = null;
				}
				eventsInitialized = false;

				if (focusTimer != null)
				{
					focusTimer.Stop();
					focusTimer = null;
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ClaudeTerminalControl_Unloaded: {ex}");
			}
		}

		private void SolutionEvents_Opened()
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				string projectDir = GetActiveProjectDirectory();
				if (!string.IsNullOrEmpty(projectDir))
				{
					foreach (var tab in agentTabs)
					{
						if (tab.CurrentSolutionPath == projectDir)
						{
							continue;
						}
						tab.CurrentSolutionPath = projectDir;
						RestartClaudeWithWorkingDirectory(tab, projectDir);
					}
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SolutionEvents_Opened: {ex}");
			}
		}

		private void SolutionEvents_AfterClosing()
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				foreach (var tab in agentTabs)
				{
					tab.CurrentSolutionPath = null;
				}
				StopClaude();
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SolutionEvents_AfterClosing: {ex}");
			}
		}

		private DTE2 GetDTE()
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				if (claudeTerminal != null)
				{
					DTE2 result = claudeTerminal.GetService<EnvDTE.DTE, EnvDTE.DTE>() as DTE2;
					if (result != null)
						return result;
				}

				return (DTE2)System.Runtime.InteropServices.Marshal.GetActiveObject("VisualStudio.DTE.18.0");
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in GetDTE: {ex}");
				return null;
			}
		}

		private string GetActiveProjectDirectory()
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				DTE2 localDte = dte ?? GetDTE();

				if (localDte == null || localDte.Solution == null)
				{
					return null;
				}

				if (localDte.Solution.IsOpen && !string.IsNullOrEmpty(localDte.Solution.FullName))
				{
					string solutionDir = Path.GetDirectoryName(localDte.Solution.FullName);
					return solutionDir;
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in GetActiveProjectDirectory: {ex}");
			}

			return null;
		}

		public void SendToClaude(string message, bool bEnter)
		{
			try
			{
				var terminal = activeTab?.Terminal;
				if (terminal != null)
					terminal.SendToClaude(message, bEnter);
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SendToClaude: {ex}");
			}
		}

		public void SendUserPaste(string content, bool bEnter)
		{
			if (content == null) content = string.Empty;
			var sb = new StringBuilder(content.Length + 16);
			sb.Append("\x1b[200~");
			foreach (char c in content)
			{
				if (c == '\x1b' || (c < 0x20 && c != '\r' && c != '\n' && c != '\t') || c == 0x7f)
				{
					continue;
				}
				sb.Append(c);
			}
			sb.Append("\x1b[201~");
			SendToClaude(sb.ToString(), bEnter);
		}

		private DispatcherTimer focusTimer;

		public void FocusTerminal()
		{
			try
			{
				if (focusTimer != null)
				{
					focusTimer.Stop();
				}

				var tabToFocus = lastUserSelectedTab ?? activeTab;

				focusTimer = new DispatcherTimer
				{
					Interval = TimeSpan.FromMilliseconds(100)
				};
					focusTimer.Tick += (s, e) =>
					{
						focusTimer.Stop();
						try
						{
							if (tabToFocus != null && AgentTabs.SelectedItem != tabToFocus.TabItem)
							{
								AgentTabs.SelectedItem = tabToFocus.TabItem;
								activeTab = tabToFocus;
							}

							if (activeTab?.TerminalControl == null)
							{
								return;
							}
							var hwndHost = FindVisualChild<HwndHost>(activeTab.TerminalControl);
							if (hwndHost != null && hwndHost.Handle != IntPtr.Zero)
							{
								SetFocus(hwndHost.Handle);
							}
							activeTab.TerminalControl.Focus();
							Keyboard.Focus(activeTab.TerminalControl);
						}
						catch (Exception ex)
						{
							Debug.WriteLine($"Exception in FocusTerminal timer: {ex}");
					}
				};
				focusTimer.Start();
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in FocusTerminal: {ex}");
			}
		}

		private static T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
		{
			for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
			{
				var child = VisualTreeHelper.GetChild(parent, i);
				if (child is T result)
					return result;
				var descendant = FindVisualChild<T>(child);
				if (descendant != null)
					return descendant;
			}
			return null;
		}

		private void ClaudeTerminalControl_GotFocus(object sender, RoutedEventArgs e)
		{
			if (e.OriginalSource == this)
			{
				FocusTerminal();
				e.Handled = true;
			}
		}

		private void ClaudeTerminalControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
		}

		public ConPtyTerminal ActiveTerminal => activeTab?.Terminal;
		public ConPtyTerminalConnection ActiveConnection => activeTab?.Connection;

		public IntPtr TerminalHwnd
		{
			get
			{
				if (activeTab == null) return IntPtr.Zero;
				if (activeTab.TerminalHwnd != IntPtr.Zero) return activeTab.TerminalHwnd;
				if (activeTab.TerminalControl != null)
				{
					var hwndHost = FindVisualChild<HwndHost>(activeTab.TerminalControl);
					if (hwndHost != null && hwndHost.Handle != IntPtr.Zero)
					{
						activeTab.TerminalHwnd = hwndHost.Handle;
					}
				}
				return activeTab?.TerminalHwnd ?? IntPtr.Zero;
			}
		}

		public IntPtr TerminalHandle
		{
			get
			{
				ThreadHelper.ThrowIfNotOnUIThread();
				if (activeTab == null) return IntPtr.Zero;
				if (activeTab.TerminalHandle != IntPtr.Zero) return activeTab.TerminalHandle;
				ExtractTerminalHandle(activeTab);
				return activeTab?.TerminalHandle ?? IntPtr.Zero;
			}
		}

		private async System.Threading.Tasks.Task ApplyPendingResizeAndRefreshAsync(AgentTab tab)
		{
			await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
			ApplyPendingResizeAndRefresh(tab);
		}

		private void ApplyPendingResizeAndRefresh(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			var connection = tab.Connection;
			if (connection != null)
			{
				connection.IsPaused = IsTerminalSelectionActive(tab);
			}

			if (tab.NeedsResizeAfterOutput)
			{
				tab.NeedsResizeAfterOutput = false;
				ApplyFontSize(tab);
				StartRefreshTimer(tab);
			}
		}

		private void ConPtyTerminal_OutputReceived(AgentTab tab, string e)
		{
			AppendRecentTranscript(tab, e);
			tab.LastOutputTime = DateTime.UtcNow;
			_ = ApplyPendingResizeAndRefreshAsync(tab);

			if (isMarkdownMode && tab == activeTab)
			{
				ParseAndDisplayMarkdown(e);
			}
		}

		private void AppendRecentTranscript(AgentTab tab, string output)
		{
			if (tab == null || string.IsNullOrEmpty(output))
			{
				return;
			}

			lock (tab.TranscriptLock)
			{
				tab.RecentTranscript.Append(output);
				if (tab.RecentTranscript.Length > QuickSwitchTranscriptLimit)
				{
					tab.RecentTranscript.Remove(0, tab.RecentTranscript.Length - QuickSwitchTranscriptLimit);
				}
			}
		}

		private void ClearRecentTranscript(AgentTab tab)
		{
			if (tab == null)
			{
				return;
			}

			lock (tab.TranscriptLock)
			{
				tab.RecentTranscript.Clear();
			}
		}

		private string GetRecentTranscriptSnapshot(AgentTab tab)
		{
			if (tab == null)
			{
				return string.Empty;
			}

			lock (tab.TranscriptLock)
			{
				return tab.RecentTranscript.ToString();
			}
		}

		private string NormalizeTerminalOutput(string text)
		{
			if (string.IsNullOrEmpty(text))
			{
				return string.Empty;
			}

			var builder = new StringBuilder(text.Length);
			for (int i = 0; i < text.Length; i++)
			{
				char c = text[i];
				if (c == '\u001b')
				{
					i = SkipAnsiSequence(text, i);
					continue;
				}

				builder.Append(c == '\u00a0' ? ' ' : c);
			}

			return builder.ToString().Replace("\r\n", "\n").Replace('\r', '\n');
		}

		private int SkipAnsiSequence(string text, int index)
		{
			int nextIndex = index + 1;
			if (nextIndex >= text.Length)
			{
				return index;
			}

			char next = text[nextIndex];
			if (next == '[')
			{
				nextIndex++;
				while (nextIndex < text.Length)
				{
					char ch = text[nextIndex];
					if (ch >= '@' && ch <= '~')
					{
						return nextIndex;
					}
					nextIndex++;
				}
				return text.Length - 1;
			}

			if (next == ']')
			{
				nextIndex++;
				while (nextIndex < text.Length)
				{
					if (text[nextIndex] == '\u0007')
					{
						return nextIndex;
					}

					if (text[nextIndex] == '\u001b' && nextIndex + 1 < text.Length && text[nextIndex + 1] == '\\')
					{
						return nextIndex + 1;
					}

					nextIndex++;
				}
				return text.Length - 1;
			}

			return nextIndex;
		}

		private bool RecentTranscriptContains(AgentTab tab, string value)
		{
			if (string.IsNullOrEmpty(value))
			{
				return false;
			}

			string normalizedTranscript = NormalizeTerminalOutput(GetRecentTranscriptSnapshot(tab));
			string normalizedValue = NormalizeTerminalOutput(value);
			return normalizedTranscript.IndexOf(normalizedValue, StringComparison.OrdinalIgnoreCase) >= 0;
		}

		private void ShowToolWindowFrame()
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			(claudeTerminal?.Frame as IVsWindowFrame)?.Show();
		}

		private void ShowToolWindowFrameOnMainThread()
		{
			ThreadHelper.JoinableTaskFactory.Run(async delegate
			{
				await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
				ShowToolWindowFrame();
			});
		}

		private void ExtractTerminalHandle(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var termContainerField = tab.TerminalControl.GetType().GetField("termContainer", BindingFlags.NonPublic | BindingFlags.Instance);
				if (termContainerField != null)
				{
					var termContainer = termContainerField.GetValue(tab.TerminalControl);
					if (termContainer != null)
					{
						tab.TermContainerInstance = termContainer;

						var terminalField = termContainer.GetType().GetField("terminal", BindingFlags.NonPublic | BindingFlags.Instance);
						if (terminalField != null)
						{
							tab.TerminalHandle = (IntPtr)terminalField.GetValue(termContainer);
						}

						var hwndField = termContainer.GetType().GetField("hwnd", BindingFlags.NonPublic | BindingFlags.Instance);
						if (hwndField != null)
						{
							tab.TerminalHwnd = (IntPtr)hwndField.GetValue(termContainer);
						}

						tab.UserScrollMethod = termContainer.GetType().GetMethod("UserScroll", BindingFlags.NonPublic | BindingFlags.Instance);

						if (!tab.MouseHookInstalled && termContainer is HwndHost hwndHost)
						{
							hwndHost.MessageHook += delegate(IntPtr h, int m, IntPtr w, IntPtr l, ref bool hd)
							{
								if (m == WM_LBUTTONDOWN)
								{
									ShowToolWindowFrameOnMainThread();
									SetFocus(h);
								}
								return IntPtr.Zero;
							};
							tab.MouseHookInstalled = true;
						}
					}
				}

				var scrollbarField = tab.TerminalControl.GetType().GetField("scrollbar", BindingFlags.NonPublic | BindingFlags.Instance);
				if (scrollbarField != null)
				{
					tab.TerminalScrollbar = scrollbarField.GetValue(tab.TerminalControl) as ScrollBar;
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ExtractTerminalHandle: {ex}");
			}
		}

		private bool IsTerminalSelectionActive(AgentTab tab)
		{
			try
			{
				if (tab.TerminalHandle != IntPtr.Zero)
				{
					return TerminalIsSelectionActive(tab.TerminalHandle);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in IsTerminalSelectionActive: {ex}");
			}
			return false;
		}

		private void StartRefreshTimer(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			if (tab.RefreshTimer == null)
			{
				tab.RefreshTimer = new DispatcherTimer
				{
					Interval = TimeSpan.FromMilliseconds(500)
				};
				tab.RefreshTimer.Tick += (s, e) => RefreshTimer_Tick(tab);
			}
			tab.RefreshTimer.Start();

			StartSelectionScrollTimer(tab);
		}

		private void StartSelectionScrollTimer(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			if (tab.SelectionScrollTimer == null)
			{
				tab.SelectionScrollTimer = new DispatcherTimer(DispatcherPriority.Input)
				{
					Interval = TimeSpan.FromMilliseconds(16)
				};
				tab.SelectionScrollTimer.Tick += (s, e) => SelectionScrollTimer_Tick(tab);
			}
			tab.SelectionScrollTimer.Start();
		}

		private bool IsLeftMouseButtonDown()
		{
			return (GetAsyncKeyState(VK_LBUTTON) & 0x8000) != 0;
		}

		private bool wasMouseButtonDown = false;
		private bool mouseDownStartedInTerminal = false;

		private void SelectionScrollTimer_Tick(AgentTab tab)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				if (tab.TerminalHwnd == IntPtr.Zero)
				{
					ExtractTerminalHandle(tab);
					if (tab.TerminalHwnd == IntPtr.Zero)
					{
						return;
					}
				}

				bool isMouseDown = IsLeftMouseButtonDown();

				if (!isMouseDown)
				{
					wasMouseButtonDown = false;
					mouseDownStartedInTerminal = false;
					return;
				}

				if (!GetCursorPos(out POINT cursorPos))
				{
					return;
				}

				var terminalPoint = tab.TerminalControl.PointFromScreen(new Point(cursorPos.X, cursorPos.Y));

				if (!wasMouseButtonDown)
				{
					wasMouseButtonDown = true;
					mouseDownStartedInTerminal = terminalPoint.X >= 0 && terminalPoint.X <= tab.TerminalControl.ActualWidth &&
					                             terminalPoint.Y >= 0 && terminalPoint.Y <= tab.TerminalControl.ActualHeight;
				}

				if (!mouseDownStartedInTerminal)
				{
					return;
				}

				double edgeMargin = 20;
				double terminalTop = edgeMargin;
				double terminalBottom = tab.TerminalControl.ActualHeight - edgeMargin;

				bool isOutsideBounds = terminalPoint.Y < terminalTop || terminalPoint.Y > terminalBottom;
				if (!isOutsideBounds)
				{
					return;
				}

				int wheelDelta = 0;

				if (terminalPoint.Y < terminalTop)
				{
					double distance = terminalTop - terminalPoint.Y;
					int scrollSpeed = Math.Max(1, Math.Min(3, (int)(distance / 50) + 1));
					wheelDelta = (WHEEL_DELTA / 2) * scrollSpeed;
				}
				else if (terminalPoint.Y > terminalBottom)
				{
					double distance = terminalPoint.Y - terminalBottom;
					int scrollSpeed = Math.Max(1, Math.Min(3, (int)(distance / 50) + 1));
					wheelDelta = -(WHEEL_DELTA / 2) * scrollSpeed;
				}

				if (wheelDelta != 0)
				{
					int wParam = (wheelDelta << 16) | MK_LBUTTON;
					int lParam = (cursorPos.Y << 16) | (cursorPos.X & 0xFFFF);
					SendMessage(tab.TerminalHwnd, WM_MOUSEWHEEL, (IntPtr)wParam, (IntPtr)lParam);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SelectionScrollTimer_Tick: {ex}");
			}
		}

		private void RefreshTimer_Tick(AgentTab tab)
		{
			try
			{
				bool isSelecting = IsTerminalSelectionActive(tab);

				var connection = tab.Connection;
				if (connection != null)
				{
					connection.IsPaused = isSelecting;
				}

				if (!isSelecting &&
					(DateTime.UtcNow - tab.LastOutputTime).TotalMilliseconds < 1000 &&
					tab.TerminalControl.ActualHeight > 0 && tab.TerminalControl.ActualWidth > 0)
				{
					var theme = GetTerminalTheme();
					var bgColor = GetThemeBackgroundColor();
					tab.TerminalControl.SetTheme(theme, "Consolas", currentFontSize, bgColor);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in RefreshTimer_Tick: {ex}");
			}
		}

		private void ChangeCommandButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var dialog = new CommandInputDialog(activeTab?.Command ?? currentCommand);
				dialog.Owner = Application.Current?.MainWindow;
				if (dialog.ShowDialog() == true)
				{
					string newCommand = dialog.CommandName?.Trim();
					if (!string.IsNullOrWhiteSpace(newCommand) && !string.Equals(newCommand, activeTab?.Command ?? currentCommand, StringComparison.OrdinalIgnoreCase))
					{
						if (activeTab == null)
						{
							return;
						}
						activeTab.Command = newCommand;
						currentCommand = newCommand;
						SettingsManager.SaveLastCommand(currentCommand);
						UpdateQuickSwitchVisibility();
						activeTab.NeedsResizeAfterOutput = true;
						string projectDir = GetActiveProjectDirectory();
						if (!string.IsNullOrEmpty(projectDir))
						{
							activeTab.CurrentSolutionPath = projectDir;
							RestartClaudeWithWorkingDirectory(activeTab, projectDir);
						}
						else
						{
							activeTab.CurrentSolutionPath = null;
							StopClaude(activeTab);
							InitializeConPtyTerminal(activeTab);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in ChangeCommandButton_Click: {ex}");
			}
		}

		private void RestartAgentButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				if (activeTab == null)
				{
					return;
				}
				activeTab.NeedsResizeAfterOutput = true;
				string projectDir = GetActiveProjectDirectory();
				if (!string.IsNullOrEmpty(projectDir))
				{
					activeTab.CurrentSolutionPath = projectDir;
					RestartClaudeWithWorkingDirectory(activeTab, projectDir);
				}
				else
				{
					activeTab.CurrentSolutionPath = null;
					StopClaude(activeTab);
					InitializeConPtyTerminal(activeTab);
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in RestartAgentButton_Click: {ex}");
			}
		}

		private void MicButton_Checked(object sender, RoutedEventArgs e)
		{
			try
			{
				var speechCommand = SpeechCommand.Instance;
				if (speechCommand != null)
				{
					speechCommand.ListeningStateChanged -= OnListeningStateChanged;
					speechCommand.ListeningStateChanged += OnListeningStateChanged;
					speechCommand.StartListening();
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in MicButton_Checked: {ex}");
				MicButton.IsChecked = false;
			}
		}

		private void MicButton_Unchecked(object sender, RoutedEventArgs e)
		{
			try
			{
				var speechCommand = SpeechCommand.Instance;
				if (speechCommand != null && speechCommand.IsListening)
				{
					_ = speechCommand.StopListeningAsync();
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in MicButton_Unchecked: {ex}");
			}
		}

		private async System.Threading.Tasks.Task UpdateListeningStateAsync(bool isListening)
		{
			await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
			MicButton.IsChecked = isListening;
		}

		private void OnListeningStateChanged(bool isListening)
		{
			_ = UpdateListeningStateAsync(isListening);
		}

		private void LanguageButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				LanguageManager.CurrentLanguage = LanguageManager.CurrentLanguage == ClaudeVSGui.Language.English ? ClaudeVSGui.Language.Chinese : ClaudeVSGui.Language.English;
				LanguageManager.SaveLanguage();
				UpdateLanguage();
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in LanguageButton_Click: {ex}");
			}
		}

		private void UpdateLanguage()
		{
			MicButton.ToolTip = LanguageManager.Get("Mic");
			ViewModeButton.ToolTip = LanguageManager.CurrentLanguage == ClaudeVSGui.Language.Chinese ? "切换视图模式" : "Toggle View Mode";
			ChangeCommandButton.ToolTip = LanguageManager.Get("ChangeAgent");
			RestartAgentButton.ToolTip = LanguageManager.Get("RestartAgent");
			NewAgentButton.ToolTip = LanguageManager.Get("NewAgent");
			ThemeButton.ToolTip = LanguageManager.Get("Theme");
			FontSizeButton.ToolTip = LanguageManager.Get("FontSize");
			QuickSwitchButton.ToolTip = LanguageManager.Get("QuickSwitch");
			SendImageButton.ToolTip = LanguageManager.Get("SendImage");
			LanguageButton.ToolTip = LanguageManager.Get("Language");
			SettingsButton.ToolTip = LanguageManager.CurrentLanguage == ClaudeVSGui.Language.Chinese ? "设置" : "Settings";
		}

		private void SendImageButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var command = SendImageCommand.Instance;
				if (command != null)
				{
					command.ExecuteFromButton();
				}
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SendImageButton_Click: {ex}");
			}
		}

		private void SettingsButton_Click(object sender, RoutedEventArgs e)
		{
			ThreadHelper.ThrowIfNotOnUIThread();
			try
			{
				var popup = new Popup
				{
					StaysOpen = false,
					AllowsTransparency = true,
					PlacementTarget = sender as UIElement,
					Placement = PlacementMode.Bottom,
				};

				string effectiveTheme = currentTheme;
				if (effectiveTheme == "System")
					effectiveTheme = IsSystemDarkMode() ? "Dark" : "Light";
				bool isDark = effectiveTheme != "Light";

				var bgBrush = isDark
					? new SolidColorBrush(Color.FromRgb(0x2D, 0x2D, 0x30))
					: new SolidColorBrush(Color.FromRgb(0xF5, 0xF5, 0xF5));
				var borderBrush = isDark
					? new SolidColorBrush(Color.FromRgb(0x3F, 0x3F, 0x46))
					: new SolidColorBrush(Color.FromRgb(0xCC, 0xCC, 0xCC));
				var fgBrush = isDark
					? new SolidColorBrush(Color.FromRgb(0xD4, 0xD4, 0xD4))
					: new SolidColorBrush(Color.FromRgb(0x1E, 0x1E, 0x1E));

				var border = new Border
				{
					Background = bgBrush,
					BorderBrush = borderBrush,
					BorderThickness = new Thickness(1),
					Padding = new Thickness(8),
					MinWidth = 150
				};

				var stack = new StackPanel();

				var fontSizeBtn = new Button
				{
					Content = LanguageManager.Get("FontSize"),
					Padding = new Thickness(8, 4, 8, 4),
					Margin = new Thickness(0, 0, 0, 4),
					Background = Brushes.Transparent,
					Foreground = fgBrush,
					BorderThickness = new Thickness(0),
					HorizontalContentAlignment = HorizontalAlignment.Left,
					Cursor = Cursors.Hand
				};
				fontSizeBtn.Click += (s, ev) => { popup.IsOpen = false; FontSizeButton_Click(s, ev); };

				var changeAgentBtn = new Button
				{
					Content = LanguageManager.Get("ChangeAgent"),
					Padding = new Thickness(8, 4, 8, 4),
					Margin = new Thickness(0, 0, 0, 4),
					Background = Brushes.Transparent,
					Foreground = fgBrush,
					BorderThickness = new Thickness(0),
					HorizontalContentAlignment = HorizontalAlignment.Left,
					Cursor = Cursors.Hand
				};
				changeAgentBtn.Click += (s, ev) => { popup.IsOpen = false; ChangeCommandButton_Click(s, ev); };

				stack.Children.Add(fontSizeBtn);
				stack.Children.Add(changeAgentBtn);

				border.Child = stack;
				popup.Child = border;
				popup.IsOpen = true;
			}
			catch (Exception ex)
			{
				Debug.WriteLine($"Exception in SettingsButton_Click: {ex}");
			}
		}

		private void ViewModeButton_Checked(object sender, RoutedEventArgs e)
		{
			isMarkdownMode = true;
			AgentTabs.Visibility = Visibility.Collapsed;
			MarkdownChat.Visibility = Visibility.Visible;
			UpdateMarkdownTheme();
		}

		private void ViewModeButton_Unchecked(object sender, RoutedEventArgs e)
		{
			isMarkdownMode = false;
			AgentTabs.Visibility = Visibility.Visible;
			MarkdownChat.Visibility = Visibility.Collapsed;
		}

		private void UpdateMarkdownTheme()
		{
			string effectiveTheme = currentTheme;
			if (effectiveTheme == "System")
				effectiveTheme = IsSystemDarkMode() ? "Dark" : "Light";
			MarkdownChat.SetTheme(effectiveTheme != "Light");
		}

		private void ParseAndDisplayMarkdown(string output)
		{
			if (string.IsNullOrEmpty(output))
				return;

			string normalized = NormalizeTerminalOutput(output);

			if (normalized.Contains(">") && !isCollectingAssistantMessage)
			{
				isCollectingAssistantMessage = true;
				currentAssistantMessage.Clear();
			}
			else if (isCollectingAssistantMessage)
			{
				currentAssistantMessage.Append(normalized);

				if (normalized.Contains("\n\n") || normalized.Contains("```"))
				{
					string message = currentAssistantMessage.ToString().Trim();
					if (!string.IsNullOrEmpty(message))
					{
													ThreadHelper.JoinableTaskFactory.Run(async delegate
						{
							await ThreadHelper.JoinableTaskFactory.SwitchToMainThreadAsync();
							MarkdownChat.AddAssistantMessage(message);
						});
					}
					currentAssistantMessage.Clear();
					isCollectingAssistantMessage = false;
				}
			}
		}

	}

}
