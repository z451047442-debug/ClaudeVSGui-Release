# CLAUDE.md

## Code Conventions

Don't add new comments anywhere. Don't remove existing comments unless instructed to do so.
Don't add log statements unless explicitly told to.
Don't Rebuild the project, just Build it.
Don't ever try to uninstall or install VS extensions.

## Project Overview

ClaudeVSGui is a Visual Studio 2026 extension that integrates Claude Code CLI into the IDE.

## Build Command
```bash
"D:/Program Files/Microsoft Visual Studio/18/Enterprise/MSBuild/Current/Bin/MSBuild.exe" "D:\PycharmProjects\ClaudeVSGui\ClaudeVSGui.csproj" -t:Build -p:Configuration=Debug -v:minimal
```

## Terminal DLLs (Lib/)

ClaudeVSGui embeds the Windows Terminal WPF control via two prebuilt DLLs committed to `Lib/`:

- `Lib/Microsoft.Terminal.Control.dll` — native C++ DLL with flat C ABI exports, deployed into the VSIX as Content
- `Lib/Microsoft.Terminal.Wpf.dll` — managed C# wrapper, referenced as an assembly

Both Debug and Release configurations reference the same `Lib/` copy. To rebuild these from Windows Terminal source, see the upstream microsoft/terminal repo (v143 toolset, VS 2022 required for the native code). After producing fresh DLLs, overwrite the two files in `Lib/`.

### After replacing the DLLs

If the VS experimental instance has a cached copy of the extension, also copy the new DLLs into the extension deployment directory. The path contains a host-specific hash; find yours with:

```
dir "%LOCALAPPDATA%\Microsoft\VisualStudio" | findstr Exp
```

Then copy both DLLs into `%LOCALAPPDATA%\Microsoft\VisualStudio\<VERSION>_<HASH>Exp\Extensions\Essen.Zhao\ClaudeVSGui - Claude Code Integration\<EXT_VERSION>\` and restart the experimental instance.

### Native API surface

The WPF terminal control uses a flat C ABI to call into the native DLL. Adding new native methods requires changes in all layers of the upstream terminal source:
1. `HwndTerminal.hpp` / `HwndTerminal.cpp` — declare and implement the extern "C" function
2. `Microsoft.Terminal.Control.def` — add the export
3. `NativeMethods.cs` — add the P/Invoke declaration
4. `TerminalContainer.cs` — add an internal wrapper
5. `TerminalControl.xaml.cs` — add the public method